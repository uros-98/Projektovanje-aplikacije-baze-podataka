<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" 
        rel="stylesheet" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <title>Login</title>
        <link rel="stylesheet" href="CSS/stylelogin.css">
    </head>
    <body>

        <div class="container">
            <div class="card">
                <div class="card-body">
                    <div class="text-center">
                    <form action="PHP/log.php" method="post">
                    <h5 class="text-center">Prijava korisnika</h5>
                        <div class="form-group">
                            <label for="email">Email:</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="name@example.com">
                        </div>
                        <div class="form-group">
                            <label for="password">Lozinka</label>
                            <input type="password" class="form-control" id="password" name="password">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="gridCheck"></input>
                                    <label class="form-check-label" for="gridCheck">Remember me</label>
                                    <div class="text-center mt-2" style="padding-right: 100px; padding-top: 20px;">
                        <a href="registracija.php">Nemate nalog? Registrujte se</a>
                    </div>
                                </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Prijavi se</button>
                    </form>
                    
                </div>
            </div>
        </div> 
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js" 
        integrity="sha384-6khuMg9gaYr5AxOqhkVIODVIvm9ynTT5J4V1cfthmT+emCG6yVmEZsRHdxlotUnm" crossorigin="anonymous"></script>    
    </body>
</html>
