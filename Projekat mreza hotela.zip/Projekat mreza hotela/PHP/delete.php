<?php 

require 'connection.php';

session_start();


if(!isset($_SESSION['korisnik_id'])) {
    header("Location: ../index.php");
    exit();
}

$id = $_GET['id'];
$upit = "DELETE FROM hotel WHERE hotel_id=$id";
// $pdo_izraz = $this->dbh->exec($upit);

if(mysqli_query($conn, $upit)) {
    echo "Uspesno ste obrisali hotel";
    header("Location: ../lista_hotela.php");
} else {
    echo "Greska prilikom brisanja: " . mysqli_error($conn);
}

mysqli_close($conn);
?>