<?php

    require 'connection.php';

    if($_SERVER['REQUEST_METHOD'] === 'POST') {
        
        $id = $_POST['id'];
        $naziv = $_POST['naziv'];
        $grad = $_POST['grad'];
        $drzava = $_POST['drzava'];

        $sql = "UPDATE hotel 
        SET naziv='$naziv',grad='$grad',drzava='$drzava' 
        WHERE hotel_id = $id";
        if(mysqli_query($conn, $sql)) {
            echo "Uspesno ste se registrovali";
            header("Location: ../lista_hotela.php");
        } else {
            echo "Greska prilikom izmene: " . mysqli_error($conn);
        }
    }
    mysqli_close($conn);
?>