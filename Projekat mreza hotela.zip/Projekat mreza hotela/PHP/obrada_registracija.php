<?php
    require 'connection.php';

    if($_SERVER['REQUEST_METHOD'] === 'POST') {
        $ime = $_POST['ime'];
        $prezime = $_POST['prezime'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $username = $_POST['username'];
        $password_hash = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO korisnici (ime, prezime, email, password, username) VALUES ('$ime', '$prezime', '$email', '$password_hash', '$username')";

        if(mysqli_query($conn, $sql)) {
            echo "Uspesno ste se registrovali";
            header("Location: ../index.php");
        } else {
            echo "Greska prilikom registracije: " . mysqli_error($conn);
        }
    }
    
    mysqli_close($conn);
?>