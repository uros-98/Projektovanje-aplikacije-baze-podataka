<?php 

    session_start();

    if (isset($_SESSION['korisnik_id'])) {
        session_unset(); 
        session_destroy();
    }

    header("Location: ../index.php");
    
    echo "test";
    exit();

?>