<?php 

require 'PHP/connection.php';

session_start();

if(!isset($_SESSION['korisnik_id'])) {
    header("Location: ../index.php");
    exit();
}

$id = $_GET['id']; 
$upit = "SELECT * FROM hotel WHERE hotel_id = $id";
$rezultat = mysqli_query($conn, $upit);

if (mysqli_num_rows($rezultat) === 1) {
    $hotel = mysqli_fetch_assoc($rezultat);
} else {
    header("Location: ../lista_hotela.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" 
        rel="stylesheet" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <link rel="stylesheet" href="CSS/styleregister.css">
        <title>Izmena hotela</title>
    </head>
    <body>

        <div class="container">
            <form action="PHP/izmeni_hotel.php" method="post">
            <h2>Izmena hotela</h2>
            <input type="hidden" class="form-control" id="id" name="id" value="<?php echo $hotel['hotel_id']?>" required>
                <div class="form-group">
                    <label for="naziv">Naziv:</label>
                    <input type="text" class="form-control" id="naziv" name="naziv" value="<?php echo $hotel['naziv']?>" required>
                </div>
                <div class="form-group">
                    <label for="drzava">Drzava:</label>
                    <input type="text" class="form-control" id="drzava" name="drzava" value="<?php echo $hotel['drzava']?>" required>
                </div>
                <div class="form-group">
                    <label for="grad">Grad:</label>
                    <input type="text" class="form-control" id="grad" name="grad" value="<?php echo $hotel['grad']?>" required>
                </div>
   
                <button type="submit" class="btn btn-primary">Izmeni</button>
            </form>
        </div>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js" 
    integrity="sha384-6khuMg9gaYr5AxOqhkVIODVIvm9ynTT5J4V1cfthmT+emCG6yVmEZsRHdxlotUnm" crossorigin="anonymous"></script>    
    </body>
</html>


